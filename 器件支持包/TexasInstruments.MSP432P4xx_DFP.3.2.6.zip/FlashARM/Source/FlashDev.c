/* -----------------------------------------------------------------------------
 * Copyright (c) 2014 ARM Ltd.
 *
 * This software is provided 'as-is', without any express or implied warranty. 
 * In no event will the authors be held liable for any damages arising from 
 * the use of this software. Permission is granted to anyone to use this 
 * software for any purpose, including commercial applications, and to alter 
 * it and redistribute it freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not 
 *    claim that you wrote the original software. If you use this software in
 *    a product, an acknowledgment in the product documentation would be 
 *    appreciated but is not required. 
 * 
 * 2. Altered source versions must be plainly marked as such, and must not be 
 *    misrepresented as being the original software. 
 * 
 * 3. This notice may not be removed or altered from any source distribution.
 */
 
/***********************************************************************/
/*                                                                     */
/*  FlashDev.c:  Device Description adapted                            */
/*               by Texas Instruments for                              */
/*               MSP432 Flash Loader for Keil µVision IDE              */
/*                                                                     */
/***********************************************************************/
#include "..\FlashOS.H"        // FlashOS Structures

#ifdef MSP432P4_MAIN_FLASH_128KB

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 128kB Main Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00000000,                 // Device Start Address
   0x00020000,                 // Device Size in Bytes (128kB)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (32 Sectors)
   SECTOR_END
};

#endif 

#ifdef MSP432P4_MAIN_FLASH_256KB

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 256kB Main Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00000000,                 // Device Start Address
   0x00040000,                 // Device Size in Bytes (256kB)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (64 Sectors)
   SECTOR_END
};

#endif

#ifdef MSP432P4_MAIN_FLASH_512KB

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 512kB Main Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00000000,                 // Device Start Address
   0x00080000,                 // Device Size in Bytes (512kB)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (64 Sectors)
   SECTOR_END
};

#endif

#ifdef MSP432P4_MAIN_FLASH_1024KB

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 1024kB Main Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00000000,                 // Device Start Address
   0x00100000,                 // Device Size in Bytes (1024kB)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (64 Sectors)
   SECTOR_END
};

#endif

#ifdef MSP432P4_MAIN_FLASH_2048KB

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 2048kB Main Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00000000,                 // Device Start Address
   0x00200000,                 // Device Size in Bytes (2048kB)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (64 Sectors)
   SECTOR_END
};

#endif

#ifdef MSP432P4_INFO_FLASH

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 16kB Information Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00200000,                 // Device Start Address
   0x00004000,                 // Device Size in Bytes (lower 8kB available, upper 8kB occupied by BSL)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (4 Sectors)
   SECTOR_END
};

#endif

#ifdef MSP432P4_INFO_FLASH_A

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "MSP432P4xx 32kB Information Flash Memory",   // Device Name 
   ONCHIP,                     // Device Type
   0x00200000,                 // Device Start Address
   0x00008000,                 // Device Size in Bytes (lower 8kB available, 8kB occupied by BSL, 16kB available)
   4096,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   600,                        // Program Page Timeout 600 mSec
   3000,                       // Erase Sector Timeout 3000 mSec

// Specify Size and Address of Sectors
   0x001000, 0x00000000,         // Sector Size  4kB (4 Sectors)
   SECTOR_END
};

#endif
