/* -----------------------------------------------------------------------------
 * Copyright (c) 2014 ARM Ltd.
 *
 * This software is provided 'as-is', without any express or implied warranty. 
 * In no event will the authors be held liable for any damages arising from 
 * the use of this software. Permission is granted to anyone to use this 
 * software for any purpose, including commercial applications, and to alter 
 * it and redistribute it freely, subject to the following restrictions:
 *
 * 1. The origin of this software must not be misrepresented; you must not 
 *    claim that you wrote the original software. If you use this software in
 *    a product, an acknowledgment in the product documentation would be 
 *    appreciated but is not required. 
 * 
 * 2. Altered source versions must be plainly marked as such, and must not be 
 *    misrepresented as being the original software. 
 * 
 * 3. This notice may not be removed or altered from any source distribution.
 */
 
/***********************************************************************/
/*                                                                     */
/*  FlashPrg.c:  Flash Programming Functions adapted                   */
/*               by Texas Instruments for                              */
/*               MSP432 Flash Loader for Keil �Vision IDE              */
/*                                                                     */
/*  Version:     3.0.0                                                 */
/*  Date:        2016-12-07                                            */
/***********************************************************************/


// Defines
#define BUILD_FOR_ROM
#define FLASH_MAX_REPEATS       5
#define INFO_FLASH_START   __INFO_FLASH_A_TECH_START__
#define INFO_FLASH_MIDDLE  __INFO_FLASH_A_TECH_MIDDLE__
#define BSL_FLASH_START    BSL_API_TABLE_ADDR

#include <stdint.h>
#include <stdbool.h>

#include "..\FlashOS.H"        // FlashOS Structures

#include "msp.h"
#include "driverlib.h"


/******************************************************************************
* Variables for back-up of system state
******************************************************************************/

static uint32_t SRAM_BANKEN_RESTORE;
static uint32_t BANK0_WAIT_RESTORE;
static uint32_t BANK1_WAIT_RESTORE;
static uint32_t CS_DC0_FREQ_RESTORE;
static uint8_t  PCM_VCORE_LEVEL_RESTORE;

// Function prototypes
void unlockAllFlashSectors(bool eraseBSL);
void lockAllFlashSectors(void);
	
/*
 *  Initialize Flash Programming Functions
 *    Parameter:      adr:  Device Base Address
 *                    clk:  Clock Frequency (Hz)
 *                    fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */
int Init (unsigned long adr, unsigned long clk, unsigned long fnc) {

	bool success;
	
    // Halt watchdog
    WDT_A_holdTimer();


	// Enable all SRAM banks (if disabled by user code)
	SRAM_BANKEN_RESTORE = SYSCTL_A->SRAM_BANKEN_CTL0;
    while(!(SYSCTL_A->SRAM_STAT & SYSCTL_A_SRAM_STAT_BNKEN_RDY));    
    if (SYSCTL_A->SRAM_NUMBANKS == 4)
    {
    	SYSCTL_A->SRAM_BANKEN_CTL0 = SYSCTL_A_SRAM_BANKEN_CTL0_BNK3_EN;
    }
    else
    {
    	SYSCTL_A->SRAM_BANKEN_CTL0 = SYSCTL_A_SRAM_BANKEN_CTL0_BNK1_EN;
    }

	// read parametes for restore
	BANK0_WAIT_RESTORE = MAP_FlashCtl_A_getWaitState(FLASH_A_BANK0);
	BANK1_WAIT_RESTORE = MAP_FlashCtl_A_getWaitState(FLASH_A_BANK1);
	PCM_VCORE_LEVEL_RESTORE = MAP_PCM_getPowerState();
	CS_DC0_FREQ_RESTORE = CS->CTL0 & CS_CTL0_DCORSEL_MASK;

	// Switch to AM0_LDO
	success = MAP_PCM_setPowerState(PCM_AM_LDO_VCORE0);
	if (!success)
	{
		return (1);
	}

	// Set Flash wait states to 2
	MAP_FlashCtl_A_setWaitState(FLASH_A_BANK0, 2);
	MAP_FlashCtl_A_setWaitState(FLASH_A_BANK1, 2);

	// Set CPU speed to 24MHz
	MAP_CS_setDCOCenteredFrequency(CS_DCO_FREQUENCY_24);

	
  return (0);                                  // Finished without Errors
}


/*
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int UnInit (unsigned long fnc) {

  bool success;
  
	// Restore modified registers, in reverse order
	MAP_FlashCtl_A_setWaitState(FLASH_A_BANK0, BANK0_WAIT_RESTORE);
	MAP_FlashCtl_A_setWaitState(FLASH_A_BANK1, BANK1_WAIT_RESTORE);

	success = MAP_PCM_setPowerState(PCM_VCORE_LEVEL_RESTORE);

	if(!success)
	{
		return (1);
	}

	MAP_CS_setDCOCenteredFrequency(CS_DC0_FREQ_RESTORE);

	// Restore SRAM banks settings
	SYSCTL_A->SRAM_BANKEN_CTL0 = SRAM_BANKEN_RESTORE;


  return (0);                                  // Finished without Errors
}


/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseChip (void) {

  int eraseRepeats = FLASH_MAX_REPEATS;
  bool success = false;
  
  // Allow flash writes
  unlockAllFlashSectors(false);

  // Allow some sector erase repeats before timeout with error
  while (!success && (eraseRepeats > 0))
  {
    // Sector erase with post-verify
    success = MAP_FlashCtl_A_performMassErase();
    eraseRepeats--;
  }

  // Block flash writes
  lockAllFlashSectors();

  if (eraseRepeats == 0)
  {
    return (1);
  }
  else
  {
    return (0);
  }  
}


/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseSector (unsigned long adr) {

  int eraseRepeats = FLASH_MAX_REPEATS;
  bool success = false;
  
  // Allow flash writes
  unlockAllFlashSectors(true);

  // Allow some sector erase repeats before timeout with error
  while (!success && (eraseRepeats > 0))
  {
    // Sector erase with post-verify
    success = MAP_FlashCtl_A_eraseSector((uint32_t)adr);
    eraseRepeats--;
  }

  // Block flash writes
  lockAllFlashSectors();

  if (eraseRepeats == 0)
  {
    return (1);
  }
  else
  {
    return (0);
  }  
}


/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

int ProgramPage (unsigned long adr, unsigned long sz, unsigned char *buf) {

	bool success = false;  

  // Allow flash writes
  unlockAllFlashSectors(true);

  success = MAP_FlashCtl_A_programMemory((void*)buf, (void*)adr, sz);

  // Block flash writes
  lockAllFlashSectors();

  if (!success)
  {
    return (1);
  }
  else
  {
    return (0);
  }  
}


//*****************************************************************************
//
//! Unprotect all user accessible flash sectors for erase and program
//!
//! \param None
//!
//! \return None
//
//*****************************************************************************
void unlockAllFlashSectors(bool eraseBSL)
{
    MAP_FlashCtl_A_unprotectMemory(FLASH_BASE, FLASH_BASE + MAP_SysCtl_A_getFlashSize() - 1);
    MAP_FlashCtl_A_unprotectMemory(INFO_FLASH_START, TLV_BASE - 1);
	
	  if(eraseBSL == true) {
			MAP_FlashCtl_A_unprotectMemory(BSL_FLASH_START, INFO_FLASH_MIDDLE - 1);
		}
		MAP_FlashCtl_A_unprotectMemory(INFO_FLASH_MIDDLE, MAP_SysCtl_A_getInfoFlashSize() - 1);
}

//*****************************************************************************
//
//! Protect all flash sectors against erase and program
//!
//! \param None
//!
//! \return None
//
//*****************************************************************************
void lockAllFlashSectors(void)
{
    MAP_FlashCtl_A_protectMemory(FLASH_BASE, FLASH_BASE + MAP_SysCtl_A_getFlashSize() - 1);
    MAP_FlashCtl_A_protectMemory(INFO_FLASH_START, TLV_BASE - 1);
		MAP_FlashCtl_A_protectMemory(BSL_FLASH_START, INFO_FLASH_MIDDLE - 1);
		MAP_FlashCtl_A_unprotectMemory(INFO_FLASH_MIDDLE, MAP_SysCtl_A_getInfoFlashSize() - 1);
}
